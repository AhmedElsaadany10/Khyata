using System.ComponentModel.DataAnnotations;

namespace Khayata.Application.DTOs.Customer;

// ── Requests ──────────────────────────────────────────────────────────────────

public sealed record CreateCustomerDto(
    [Required, MaxLength(200)] string Name,
    [Required, MaxLength(20)]  string PrimaryPhone,
    MeasurementsDto? Measurements);

public sealed record UpdateCustomerDto(
    [MaxLength(200)] string? Name,
    MeasurementsDto? Measurements);

public sealed record AddCustomerPhoneDto(
    [Required, MaxLength(20)] string Number,
    bool IsPrimary = false);

public sealed record MeasurementsDto(
    decimal? Height,
    decimal? Sleeve,
    decimal? ChestWidth,
    decimal? Shoulder,
    decimal? Neck);

// ── Responses ─────────────────────────────────────────────────────────────────

public sealed record CustomerResponseDto(
    Guid              Id,
    string            Name,
    DateTime          CreatedAt,
    MeasurementsDto?  Measurements,
    IReadOnlyList<CustomerPhoneDto> Phones);

public sealed record CustomerPhoneDto(Guid Id, string Number, bool IsPrimary);

public sealed record CustomerListItemDto(
    Guid   Id,
    string Name,
    string PrimaryPhone,
    DateTime CreatedAt);

// ── Query ─────────────────────────────────────────────────────────────────────

public sealed record CustomerQuery(
    string? Search,
    int     Page  = 1,
    int     Limit = 20);
