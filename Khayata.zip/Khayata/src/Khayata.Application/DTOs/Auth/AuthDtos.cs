using System.ComponentModel.DataAnnotations;

// ─────────────────────────────────────────────────────────────────────────────
// Auth DTOs
// ─────────────────────────────────────────────────────────────────────────────
namespace Khayata.Application.DTOs.Auth;

public sealed record RegisterOwnerDto(
    [Required, MaxLength(200)] string Name,
    [Required, MaxLength(20)]  string Phone,
    [Required, MinLength(8)]   string Password,
    [Required, MaxLength(200)] string WorkspaceName);

public sealed record LoginDto(
    [Required] string Phone,
    [Required] string Password);

public sealed record CreateEmployeeDto(
    [Required, MaxLength(200)] string Name,
    [Required, MaxLength(20)]  string Phone,
    [Required, MinLength(8)]   string Password);

public sealed record AuthResponseDto(
    string       AccessToken,
    string       TokenType,
    int          ExpiresIn,
    UserResponseDto  User,
    WorkspaceResponseDto? Workspace);

public sealed record RegisterResponseDto(
    string           Message,
    UserResponseDto  User,
    WorkspaceResponseDto Workspace);

public sealed record UserResponseDto(Guid Id, string Name, string Phone, string Role);
public sealed record WorkspaceResponseDto(Guid Id, string Name, string Status);
