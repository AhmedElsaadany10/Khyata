using System.ComponentModel.DataAnnotations;

// ── Employee ──────────────────────────────────────────────────────────────────
namespace Khayata.Application.DTOs.Employee;

public sealed record UpdateEmployeeDto(
    [MaxLength(200)] string? Name,
    [MinLength(8)]   string? NewPassword,
    string?                  CurrentPassword);

public sealed record EmployeeResponseDto(
    Guid   Id,
    string Name,
    string Phone,
    string Role,
    bool   IsDeleted,
    DateTime CreatedAt);

// ── Workspace ─────────────────────────────────────────────────────────────────
namespace Khayata.Application.DTOs.Workspace;

public sealed record WorkspaceDetailDto(
    Guid   Id,
    string Name,
    string Status,
    DateTime CreatedAt,
    DateTime? LastActivatedAt,
    DateTime? NextSuspensionDate);

// ── Admin ─────────────────────────────────────────────────────────────────────
namespace Khayata.Application.DTOs.Admin;

// Auth
public sealed record AdminLoginDto(
    [Required] string Username,
    [Required] string Password);

public sealed record AdminAuthResponseDto(
    string AccessToken,
    string TokenType,
    int    ExpiresIn,
    AdminUserDto User);

public sealed record AdminUserDto(Guid Id, string Username, string Role);

// Workspace management
public sealed record WorkspaceSummaryDto(
    Guid     Id,
    string   Name,
    string   Status,
    string   OwnerName,
    string   OwnerPhone,
    int      TotalOrders,
    int      TotalCustomers,
    int      TotalEmployees,
    DateTime CreatedAt,
    DateTime? NextSuspensionDate);

public sealed record AdminUpdateWorkspaceStatusDto(
    [Required] string Status,  // "Active" | "Suspended" | "PendingActivation"
    string? Reason);

// System-wide user view
public sealed record SystemUserDto(
    Guid     Id,
    Guid     WorkspaceId,
    string   WorkspaceName,
    string   Name,
    string   Phone,
    string   Role,
    bool     IsDeleted,
    DateTime CreatedAt);

// System-wide order view
public sealed record SystemOrderDto(
    Guid     Id,
    Guid     WorkspaceId,
    string   WorkspaceName,
    string   CustomerName,
    string   CreatedByName,
    decimal  TotalPrice,
    decimal  AmountPaid,
    decimal  RemainingBalance,
    string   Status,
    DateTime CreatedAt);

// Statistics / reports
public sealed record SystemStatsDto(
    int TotalWorkspaces,
    int ActiveWorkspaces,
    int PendingWorkspaces,
    int SuspendedWorkspaces,
    int TotalUsers,
    int TotalCustomers,
    int TotalOrders,
    decimal TotalRevenue,
    decimal TotalPaid);

public sealed record WorkspaceStatsDto(
    Guid    WorkspaceId,
    string  WorkspaceName,
    int     TotalOrders,
    int     PendingOrders,
    int     CompletedOrders,
    int     DeliveredOrders,
    int     TotalCustomers,
    int     TotalEmployees,
    decimal TotalRevenue,
    decimal TotalPaid,
    decimal Outstanding);

// Password reset
public sealed record AdminResetPasswordDto(
    [Required, MinLength(8)] string NewPassword);

// Audit log entry
public sealed record AuditLogDto(
    Guid     Id,
    Guid?    UserId,
    string?  UserName,
    string   Action,
    string   EntityType,
    Guid?    EntityId,
    DateTime Timestamp,
    string?  Details);

// Admin user management
public sealed record CreateAdminUserDto(
    [Required] string Username,
    [Required, MinLength(8)] string Password,
    [Required] string Role); // "SuperAdmin" | "Moderator"
