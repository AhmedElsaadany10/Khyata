using System.ComponentModel.DataAnnotations;

namespace Khayata.Application.DTOs.Order;

// ── Requests ──────────────────────────────────────────────────────────────────

public sealed record CreateOrderDto(
    [Required] Guid    CustomerId,
    [Required, MaxLength(1000)] string Description,
    [Required, Range(0.01, double.MaxValue)] decimal TotalPrice,
    [Range(0, double.MaxValue)] decimal AmountPaid,
    [Required] DateTime DeliveryDate);

public sealed record UpdateOrderDto(
    [MaxLength(1000)] string?  Description,
    decimal?                   TotalPrice,
    decimal?                   AmountPaid,
    DateTime?                  DeliveryDate,
    string?                    Status);

// ── Responses ─────────────────────────────────────────────────────────────────

public sealed record OrderResponseDto(
    Guid                 Id,
    Guid                 WorkspaceId,
    string               Description,
    decimal              TotalPrice,
    decimal              AmountPaid,
    decimal              RemainingBalance,
    string               Status,
    DateTime             DeliveryDate,
    DateTime             CreatedAt,
    DateTime             UpdatedAt,
    OrderCustomerDto     Customer,
    OrderCreatedByDto    CreatedBy);

public sealed record OrderCustomerDto(Guid Id, string Name, string PrimaryPhone);
public sealed record OrderCreatedByDto(Guid Id, string Name, string Role);

// ── Queries ───────────────────────────────────────────────────────────────────

public sealed record OrderQuery(
    string?  Status      = null,
    Guid?    CustomerId  = null,
    bool     MyOrders    = false,   // filter to orders created by the requesting user
    int      Page        = 1,
    int      Limit       = 20);
