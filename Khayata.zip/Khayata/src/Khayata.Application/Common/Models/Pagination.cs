namespace Khayata.Application.Common.Models;

public sealed class PagedResult<T>
{
    public IReadOnlyList<T> Items       { get; init; } = [];
    public int              Page        { get; init; }
    public int              Limit       { get; init; }
    public int              TotalCount  { get; init; }
    public int              TotalPages  => (int)Math.Ceiling(TotalCount / (double)Limit);
    public bool             HasNextPage => Page < TotalPages;
    public bool             HasPrevPage => Page > 1;
}

public sealed class CursorPagedResult<T>
{
    public IReadOnlyList<T> Items      { get; init; } = [];
    public string?          NextCursor { get; init; }
    public int              Limit      { get; init; }
    public int              Count      => Items.Count;
}

public sealed class PaginationQuery
{
    public int    Page   { get; init; } = 1;
    public int    Limit  { get; init; } = 20;
    public string? Cursor { get; init; }

    public int SafeLimit  => Math.Clamp(Limit, 1, 100);
    public int SafePage   => Math.Max(Page, 1);
}
