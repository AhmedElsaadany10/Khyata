using AutoMapper;
using Khayata.Application.DTOs.Admin;
using Khayata.Application.DTOs.Auth;
using Khayata.Application.DTOs.Customer;
using Khayata.Application.DTOs.Employee;
using Khayata.Application.DTOs.Order;
using Khayata.Application.DTOs.Workspace;
using Khayata.Domain.Entities;

namespace Khayata.Application.Common.Mappings;

public sealed class MappingProfile : Profile
{
    public MappingProfile()
    {
        // ── User / Auth ───────────────────────────────────────────────────────
        CreateMap<User, UserResponseDto>()
            .ConstructUsing(u => new UserResponseDto(u.Id, u.Name, u.Phone, u.Role.ToString()));

        CreateMap<User, EmployeeResponseDto>()
            .ConstructUsing(u => new EmployeeResponseDto(
                u.Id, u.Name, u.Phone, u.Role.ToString(), u.IsDeleted, u.CreatedAt));

        CreateMap<User, SystemUserDto>()
            .ForMember(d => d.WorkspaceName, opt => opt.MapFrom(s => s.Workspace != null ? s.Workspace.Name : string.Empty))
            .ConstructUsing((u, ctx) => new SystemUserDto(
                u.Id,
                u.WorkspaceId,
                u.Workspace != null ? u.Workspace.Name : string.Empty,
                u.Name, u.Phone, u.Role.ToString(), u.IsDeleted, u.CreatedAt));

        // ── Workspace ─────────────────────────────────────────────────────────
        CreateMap<Workspace, WorkspaceResponseDto>()
            .ConstructUsing(w => new WorkspaceResponseDto(w.Id, w.Name, w.Status.ToString()));

        CreateMap<Workspace, WorkspaceDetailDto>()
            .ConstructUsing(w => new WorkspaceDetailDto(
                w.Id, w.Name, w.Status.ToString(),
                w.CreatedAt, w.LastActivatedAt, w.NextSuspensionDate));

        CreateMap<Workspace, WorkspaceSummaryDto>()
            .ForMember(d => d.OwnerName,  opt => opt.MapFrom(w =>
                w.Users.FirstOrDefault(u => u.Role == Khayata.Domain.Enums.UserRole.Owner) != null
                    ? w.Users.First(u => u.Role == Khayata.Domain.Enums.UserRole.Owner).Name : "—"))
            .ForMember(d => d.OwnerPhone, opt => opt.MapFrom(w =>
                w.Users.FirstOrDefault(u => u.Role == Khayata.Domain.Enums.UserRole.Owner) != null
                    ? w.Users.First(u => u.Role == Khayata.Domain.Enums.UserRole.Owner).Phone : "—"))
            .ForMember(d => d.TotalOrders,    opt => opt.MapFrom(w => w.Orders.Count))
            .ForMember(d => d.TotalCustomers, opt => opt.MapFrom(w => w.Customers.Count))
            .ForMember(d => d.TotalEmployees, opt => opt.MapFrom(w =>
                w.Users.Count(u => u.Role == Khayata.Domain.Enums.UserRole.Employee)))
            .ForMember(d => d.Status, opt => opt.MapFrom(w => w.Status.ToString()));

        // ── Customer ──────────────────────────────────────────────────────────
        CreateMap<CustomerPhone, CustomerPhoneDto>()
            .ConstructUsing(p => new CustomerPhoneDto(p.Id, p.Number, p.IsPrimary));

        CreateMap<Measurements, MeasurementsDto>()
            .ConstructUsing(m => new MeasurementsDto(m.Height, m.Sleeve, m.ChestWidth, m.Shoulder, m.Neck));

        CreateMap<Customer, CustomerResponseDto>()
            .ForMember(d => d.Phones, opt => opt.MapFrom(c => c.Phones))
            .ConstructUsing((c, ctx) => new CustomerResponseDto(
                c.Id, c.Name, c.CreatedAt,
                c.Measurements != null ? ctx.Mapper.Map<MeasurementsDto>(c.Measurements) : null,
                ctx.Mapper.Map<IReadOnlyList<CustomerPhoneDto>>(c.Phones)));

        CreateMap<Customer, CustomerListItemDto>()
            .ForMember(d => d.PrimaryPhone, opt => opt.MapFrom(c =>
                c.Phones.FirstOrDefault(p => p.IsPrimary) != null
                    ? c.Phones.First(p => p.IsPrimary).Number
                    : c.Phones.FirstOrDefault() != null ? c.Phones.First().Number : string.Empty))
            .ConstructUsing((c, ctx) => new CustomerListItemDto(
                c.Id, c.Name,
                c.Phones.FirstOrDefault(p => p.IsPrimary)?.Number
                    ?? c.Phones.FirstOrDefault()?.Number ?? string.Empty,
                c.CreatedAt));

        // ── Order ─────────────────────────────────────────────────────────────
        CreateMap<Order, OrderResponseDto>()
            .ForMember(d => d.Status, opt => opt.MapFrom(o => o.Status.ToString()))
            .ForMember(d => d.RemainingBalance, opt => opt.MapFrom(o => o.RemainingBalance))
            .ForMember(d => d.Customer, opt => opt.MapFrom(o => o.Customer))
            .ForMember(d => d.CreatedBy, opt => opt.MapFrom(o => o.CreatedBy))
            .ConstructUsing((o, ctx) => new OrderResponseDto(
                o.Id, o.WorkspaceId, o.Description,
                o.TotalPrice, o.AmountPaid, o.RemainingBalance,
                o.Status.ToString(), o.DeliveryDate, o.CreatedAt, o.UpdatedAt,
                ctx.Mapper.Map<OrderCustomerDto>(o.Customer),
                ctx.Mapper.Map<OrderCreatedByDto>(o.CreatedBy)));

        CreateMap<Customer, OrderCustomerDto>()
            .ForMember(d => d.PrimaryPhone, opt => opt.MapFrom(c =>
                c.Phones.FirstOrDefault(p => p.IsPrimary)?.Number
                    ?? c.Phones.FirstOrDefault()?.Number ?? string.Empty))
            .ConstructUsing((c, ctx) => new OrderCustomerDto(
                c.Id, c.Name,
                c.Phones.FirstOrDefault(p => p.IsPrimary)?.Number
                    ?? c.Phones.FirstOrDefault()?.Number ?? string.Empty));

        CreateMap<User, OrderCreatedByDto>()
            .ConstructUsing(u => new OrderCreatedByDto(u.Id, u.Name, u.Role.ToString()));

        CreateMap<Order, SystemOrderDto>()
            .ForMember(d => d.WorkspaceName,   opt => opt.MapFrom(o => o.Workspace != null ? o.Workspace.Name : string.Empty))
            .ForMember(d => d.CustomerName,    opt => opt.MapFrom(o => o.Customer != null ? o.Customer.Name : string.Empty))
            .ForMember(d => d.CreatedByName,   opt => opt.MapFrom(o => o.CreatedBy != null ? o.CreatedBy.Name : string.Empty))
            .ForMember(d => d.Status,          opt => opt.MapFrom(o => o.Status.ToString()))
            .ForMember(d => d.RemainingBalance,opt => opt.MapFrom(o => o.RemainingBalance))
            .ConstructUsing((o, ctx) => new SystemOrderDto(
                o.Id, o.WorkspaceId,
                o.Workspace?.Name ?? string.Empty,
                o.Customer?.Name ?? string.Empty,
                o.CreatedBy?.Name ?? string.Empty,
                o.TotalPrice, o.AmountPaid, o.RemainingBalance,
                o.Status.ToString(), o.CreatedAt));

        // ── Admin user ────────────────────────────────────────────────────────
        CreateMap<AdminUser, AdminUserDto>()
            .ConstructUsing(a => new AdminUserDto(a.Id, a.Username, a.Role));

        // ── Audit log ─────────────────────────────────────────────────────────
        CreateMap<AuditLog, AuditLogDto>()
            .ConstructUsing(a => new AuditLogDto(
                a.Id, a.UserId, a.UserName, a.Action,
                a.EntityType, a.EntityId, a.Timestamp, a.Details));
    }
}
