namespace Khayata.Application.Common.Exceptions;

/// <summary>Base for all domain exceptions. The global middleware maps these to HTTP responses.</summary>
public abstract class DomainException(string message) : Exception(message);

public sealed class NotFoundException(string entity, object key)
    : DomainException($"{entity} with id '{key}' was not found.") { }

public sealed class ConflictException(string message) : DomainException(message) { }

public sealed class ForbiddenException(string message) : DomainException(message) { }

public sealed class ValidationException(string message) : DomainException(message) { }

public sealed class BusinessRuleException(string message) : DomainException(message) { }

public sealed class UnauthorizedException(string message) : DomainException(message) { }
