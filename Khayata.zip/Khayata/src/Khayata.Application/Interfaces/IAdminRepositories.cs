using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Admin;
using Khayata.Domain.Entities;

namespace Khayata.Application.Interfaces;

public interface IAdminRepository
{
    // Workspace management
    Task<Result<PagedResult<WorkspaceSummaryDto>>> GetWorkspacesAsync(string? status, PaginationQuery query);
    Task<Result<WorkspaceSummaryDto>>              GetWorkspaceAsync(Guid workspaceId);
    Task<Result<WorkspaceSummaryDto>>              UpdateWorkspaceStatusAsync(Guid workspaceId, AdminUpdateWorkspaceStatusDto dto);

    // System-wide user views
    Task<Result<PagedResult<SystemUserDto>>>  GetAllUsersAsync(Guid? workspaceId, string? role, PaginationQuery query);
    Task<Result<SystemUserDto>>               GetUserAsync(Guid userId);
    Task<Result>                              AdminResetPasswordAsync(Guid userId, AdminResetPasswordDto dto);
    Task<Result>                              AdminSoftDeleteUserAsync(Guid userId, Guid adminId);
    Task<Result>                              AdminRestoreUserAsync(Guid userId);

    // System-wide order views
    Task<Result<PagedResult<SystemOrderDto>>> GetAllOrdersAsync(Guid? workspaceId, string? status, PaginationQuery query);

    // Statistics
    Task<Result<SystemStatsDto>>       GetSystemStatsAsync();
    Task<Result<WorkspaceStatsDto>>    GetWorkspaceStatsAsync(Guid workspaceId);

    // Audit log
    Task<Result<PagedResult<AuditLogDto>>> GetAuditLogsAsync(Guid? entityId, string? entityType, PaginationQuery query);
    Task                                    LogAsync(AuditLog entry);
}

public interface IAdminUserRepository
{
    Task<AdminUser?> FindByUsernameAsync(string username);
    Task<AdminUser?> FindByIdAsync(Guid id);
    Task<Result<AdminAuthResponseDto>> LoginAsync(AdminLoginDto dto);
    Task<Result<AdminUserDto>>         CreateAsync(CreateAdminUserDto dto);
    Task<Result<PagedResult<AdminUserDto>>> ListAsync(PaginationQuery query);
}
