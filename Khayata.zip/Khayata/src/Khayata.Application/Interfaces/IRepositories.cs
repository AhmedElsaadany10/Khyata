using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Auth;
using Khayata.Application.DTOs.Customer;
using Khayata.Application.DTOs.Employee;
using Khayata.Application.DTOs.Order;
using Khayata.Application.DTOs.Workspace;
using Khayata.Domain.Entities;

namespace Khayata.Application.Interfaces;

// ─────────────────────────────────────────────────────────────────────────────
// Auth
// ─────────────────────────────────────────────────────────────────────────────
public interface IAuthRepository
{
    Task<Result<RegisterResponseDto>>       RegisterOwnerAsync(RegisterOwnerDto dto);
    Task<Result<AuthResponseDto>>           LoginAsync(LoginDto dto);
    Task<Result<UserResponseDto>>           CreateEmployeeAsync(Guid workspaceId, CreateEmployeeDto dto);
}

// ─────────────────────────────────────────────────────────────────────────────
// User / Employee
// ─────────────────────────────────────────────────────────────────────────────
public interface IUserRepository
{
    Task<Result<EmployeeResponseDto>>             GetEmployeeByIdAsync(Guid workspaceId, Guid userId);
    Task<Result<PagedResult<EmployeeResponseDto>>> GetEmployeesAsync(Guid workspaceId, PaginationQuery query);
    Task<Result<EmployeeResponseDto>>             UpdateEmployeeAsync(Guid workspaceId, Guid userId, UpdateEmployeeDto dto);
    Task<Result<EmployeeResponseDto>>             UpdateOwnerAsync(Guid userId, UpdateEmployeeDto dto);
    Task<Result>                                  SoftDeleteEmployeeAsync(Guid workspaceId, Guid employeeId, Guid deletedBy);

    // Used internally
    Task<User?> FindByPhoneAsync(string phone);
    Task<bool>  PhoneExistsInWorkspaceAsync(Guid workspaceId, string phone, Guid? excludeUserId = null);
}

// ─────────────────────────────────────────────────────────────────────────────
// Workspace
// ─────────────────────────────────────────────────────────────────────────────
public interface IWorkspaceRepository
{
    Task<Result<WorkspaceDetailDto>>  GetMyWorkspaceAsync(Guid workspaceId);
    Task<Workspace?>                  GetByIdRawAsync(Guid workspaceId);
    Task                              UpdateAsync(Workspace workspace);
}

// ─────────────────────────────────────────────────────────────────────────────
// Customer
// ─────────────────────────────────────────────────────────────────────────────
public interface ICustomerRepository
{
    Task<Result<CustomerResponseDto>>             CreateAsync(Guid workspaceId, Guid createdBy, CreateCustomerDto dto);
    Task<Result<CustomerResponseDto>>             GetByIdAsync(Guid workspaceId, Guid customerId);
    Task<Result<CustomerResponseDto>>             UpdateAsync(Guid workspaceId, Guid customerId, Guid updatedBy, UpdateCustomerDto dto);
    Task<Result<CustomerPhoneDto>>                AddPhoneAsync(Guid workspaceId, Guid customerId, AddCustomerPhoneDto dto);
    Task<Result>                                  RemovePhoneAsync(Guid workspaceId, Guid customerId, Guid phoneId);
    Task<Result<PagedResult<CustomerListItemDto>>> ListAsync(Guid workspaceId, CustomerQuery query);
}

// ─────────────────────────────────────────────────────────────────────────────
// Order
// ─────────────────────────────────────────────────────────────────────────────
public interface IOrderRepository
{
    Task<Result<OrderResponseDto>>             CreateAsync(Guid workspaceId, Guid createdById, CreateOrderDto dto);
    Task<Result<OrderResponseDto>>             GetByIdAsync(Guid workspaceId, Guid orderId);
    Task<Result<OrderResponseDto>>             UpdateAsync(Guid workspaceId, Guid orderId, Guid updatedBy, UpdateOrderDto dto);
    Task<Result<PagedResult<OrderResponseDto>>> ListAsync(Guid workspaceId, Guid requestingUserId, string role, OrderQuery query);
}
