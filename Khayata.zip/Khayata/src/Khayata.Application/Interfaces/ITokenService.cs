using Khayata.Domain.Entities;

namespace Khayata.Application.Interfaces;

public interface ITokenService
{
    string GenerateToken(User user);
    string GenerateAdminToken(AdminUser adminUser);
    int    ExpiresInSeconds { get; }
}
