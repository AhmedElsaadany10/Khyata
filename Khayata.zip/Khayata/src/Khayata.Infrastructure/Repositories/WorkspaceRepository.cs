using AutoMapper;
using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Workspace;
using Khayata.Application.Interfaces;
using Khayata.Domain.Entities;
using Khayata.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Khayata.Infrastructure.Repositories;

public sealed class WorkspaceRepository(AppDbContext db, IMapper mapper) : IWorkspaceRepository
{
    public async Task<Result<WorkspaceDetailDto>> GetMyWorkspaceAsync(Guid workspaceId)
    {
        var ws = await db.Workspaces.FindAsync(workspaceId);
        return ws is null
            ? Result<WorkspaceDetailDto>.Failure(ApiError.NotFound("Workspace not found."))
            : Result<WorkspaceDetailDto>.Success(mapper.Map<WorkspaceDetailDto>(ws));
    }

    public Task<Workspace?> GetByIdRawAsync(Guid workspaceId) =>
        db.Workspaces.FindAsync(workspaceId).AsTask();

    public async Task UpdateAsync(Workspace workspace)
    {
        db.Workspaces.Update(workspace);
        await db.SaveChangesAsync();
    }
}
