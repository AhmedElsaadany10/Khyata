using AutoMapper;
using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Customer;
using Khayata.Application.Interfaces;
using Khayata.Domain.Entities;
using Khayata.Infrastructure.Data;
using Khayata.Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;

namespace Khayata.Infrastructure.Repositories;

public sealed class CustomerRepository(AppDbContext db, IMapper mapper) : ICustomerRepository
{
    // ── Create ────────────────────────────────────────────────────────────────
    public async Task<Result<CustomerResponseDto>> CreateAsync(
        Guid workspaceId, Guid createdBy, CreateCustomerDto dto)
    {
        var phoneExists = await db.CustomerPhones
            .AnyAsync(p => p.WorkspaceId == workspaceId && p.Number == dto.PrimaryPhone);

        if (phoneExists)
            return Result<CustomerResponseDto>.Failure(
                ApiError.Conflict("This phone number is already registered in the workspace."));

        var customer = new Customer
        {
            WorkspaceId = workspaceId,
            Name        = dto.Name,
            CreatedBy   = createdBy,
            Phones = [new CustomerPhone
            {
                WorkspaceId = workspaceId,
                Number      = dto.PrimaryPhone,
                IsPrimary   = true,
                CreatedBy   = createdBy
            }]
        };

        if (dto.Measurements is not null)
        {
            customer.Measurements = new Measurements
            {
                CustomerId  = customer.Id,
                WorkspaceId = workspaceId,
                Height      = dto.Measurements.Height,
                Sleeve      = dto.Measurements.Sleeve,
                ChestWidth  = dto.Measurements.ChestWidth,
                Shoulder    = dto.Measurements.Shoulder,
                Neck        = dto.Measurements.Neck,
                CreatedBy   = createdBy
            };
        }

        db.Customers.Add(customer);
        await db.SaveChangesAsync();

        return await GetByIdAsync(workspaceId, customer.Id);
    }

    // ── Get by ID ─────────────────────────────────────────────────────────────
    public async Task<Result<CustomerResponseDto>> GetByIdAsync(Guid workspaceId, Guid customerId)
    {
        var customer = await db.Customers
            .Include(c => c.Measurements)
            .Include(c => c.Phones)
            .FirstOrDefaultAsync(c => c.Id == customerId && c.WorkspaceId == workspaceId);

        return customer is null
            ? Result<CustomerResponseDto>.Failure(ApiError.NotFound("Customer not found."))
            : Result<CustomerResponseDto>.Success(mapper.Map<CustomerResponseDto>(customer));
    }

    // ── Update ────────────────────────────────────────────────────────────────
    public async Task<Result<CustomerResponseDto>> UpdateAsync(
        Guid workspaceId, Guid customerId, Guid updatedBy, UpdateCustomerDto dto)
    {
        var customer = await db.Customers
            .Include(c => c.Measurements)
            .Include(c => c.Phones)
            .FirstOrDefaultAsync(c => c.Id == customerId && c.WorkspaceId == workspaceId);

        if (customer is null)
            return Result<CustomerResponseDto>.Failure(ApiError.NotFound("Customer not found."));

        if (!string.IsNullOrWhiteSpace(dto.Name))
        {
            customer.Name      = dto.Name;
            customer.UpdatedBy = updatedBy;
        }

        if (dto.Measurements is not null)
        {
            if (customer.Measurements is null)
            {
                customer.Measurements = new Measurements
                {
                    CustomerId  = customer.Id,
                    WorkspaceId = workspaceId,
                    CreatedBy   = updatedBy
                };
            }

            var m = customer.Measurements;
            m.Height      = dto.Measurements.Height     ?? m.Height;
            m.Sleeve      = dto.Measurements.Sleeve     ?? m.Sleeve;
            m.ChestWidth  = dto.Measurements.ChestWidth ?? m.ChestWidth;
            m.Shoulder    = dto.Measurements.Shoulder   ?? m.Shoulder;
            m.Neck        = dto.Measurements.Neck       ?? m.Neck;
            m.UpdatedBy   = updatedBy;
        }

        await db.SaveChangesAsync();
        return Result<CustomerResponseDto>.Success(mapper.Map<CustomerResponseDto>(customer));
    }

    // ── Phone management ──────────────────────────────────────────────────────
    public async Task<Result<CustomerPhoneDto>> AddPhoneAsync(
        Guid workspaceId, Guid customerId, AddCustomerPhoneDto dto)
    {
        var customer = await db.Customers
            .Include(c => c.Phones)
            .FirstOrDefaultAsync(c => c.Id == customerId && c.WorkspaceId == workspaceId);

        if (customer is null)
            return Result<CustomerPhoneDto>.Failure(ApiError.NotFound("Customer not found."));

        var phoneExists = await db.CustomerPhones
            .AnyAsync(p => p.WorkspaceId == workspaceId && p.Number == dto.Number);

        if (phoneExists)
            return Result<CustomerPhoneDto>.Failure(
                ApiError.Conflict("This phone number is already registered in the workspace."));

        // If this new phone is set as primary, demote the current primary
        if (dto.IsPrimary)
        {
            foreach (var existing in customer.Phones.Where(p => p.IsPrimary))
                existing.IsPrimary = false;
        }

        var phone = new CustomerPhone
        {
            CustomerId  = customerId,
            WorkspaceId = workspaceId,
            Number      = dto.Number,
            IsPrimary   = dto.IsPrimary
        };

        db.CustomerPhones.Add(phone);
        await db.SaveChangesAsync();

        return Result<CustomerPhoneDto>.Success(mapper.Map<CustomerPhoneDto>(phone));
    }

    public async Task<Result> RemovePhoneAsync(Guid workspaceId, Guid customerId, Guid phoneId)
    {
        var phone = await db.CustomerPhones
            .FirstOrDefaultAsync(p =>
                p.Id == phoneId &&
                p.CustomerId == customerId &&
                p.WorkspaceId == workspaceId);

        if (phone is null)
            return Result.Failure(ApiError.NotFound("Phone number not found."));

        // Don't allow removal of the last phone
        var count = await db.CustomerPhones
            .CountAsync(p => p.CustomerId == customerId);
        if (count <= 1)
            return Result.Failure(
                ApiError.BadRequest("Cannot remove the last phone number. Add another first."));

        // If removing the primary, promote the next available
        if (phone.IsPrimary)
        {
            var next = await db.CustomerPhones
                .Where(p => p.CustomerId == customerId && p.Id != phoneId)
                .FirstOrDefaultAsync();
            if (next is not null) next.IsPrimary = true;
        }

        db.CustomerPhones.Remove(phone);
        await db.SaveChangesAsync();
        return Result.Success();
    }

    // ── List ──────────────────────────────────────────────────────────────────
    public async Task<Result<PagedResult<CustomerListItemDto>>> ListAsync(
        Guid workspaceId, CustomerQuery query)
    {
        var q = db.Customers
            .Include(c => c.Phones)
            .Where(c => c.WorkspaceId == workspaceId);

        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            q = q.Where(c =>
                c.Name.Contains(query.Search) ||
                c.Phones.Any(p => p.Number.Contains(query.Search)));
        }

        q = q.OrderBy(c => c.Name);

        var result = await PaginationHelper.ToPagedResultAsync(
            q, query.Page, Math.Clamp(query.Limit, 1, 100),
            c => mapper.Map<CustomerListItemDto>(c));

        return Result<PagedResult<CustomerListItemDto>>.Success(result);
    }
}
