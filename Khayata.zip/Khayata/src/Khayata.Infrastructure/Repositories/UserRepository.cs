using AutoMapper;
using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Employee;
using Khayata.Application.Interfaces;
using Khayata.Domain.Entities;
using Khayata.Domain.Enums;
using Khayata.Infrastructure.Data;
using Khayata.Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;

namespace Khayata.Infrastructure.Repositories;

public sealed class UserRepository(AppDbContext db, IMapper mapper) : IUserRepository
{
    public async Task<User?> FindByPhoneAsync(string phone) =>
        await db.Users.IgnoreQueryFilters()
            .Include(u => u.Workspace)
            .FirstOrDefaultAsync(u => u.Phone == phone);

    public async Task<bool> PhoneExistsInWorkspaceAsync(Guid workspaceId, string phone, Guid? excludeUserId = null)
    {
        var q = db.Users.Where(u => u.WorkspaceId == workspaceId && u.Phone == phone);
        if (excludeUserId.HasValue) q = q.Where(u => u.Id != excludeUserId.Value);
        return await q.AnyAsync();
    }

    public async Task<Result<EmployeeResponseDto>> GetEmployeeByIdAsync(Guid workspaceId, Guid userId)
    {
        var user = await db.Users
            .FirstOrDefaultAsync(u => u.Id == userId && u.WorkspaceId == workspaceId && u.Role == UserRole.Employee);

        return user is null
            ? Result<EmployeeResponseDto>.Failure(ApiError.NotFound("Employee not found."))
            : Result<EmployeeResponseDto>.Success(mapper.Map<EmployeeResponseDto>(user));
    }

    public async Task<Result<PagedResult<EmployeeResponseDto>>> GetEmployeesAsync(
        Guid workspaceId, Application.Common.Models.PaginationQuery query)
    {
        var q = db.Users
            .Where(u => u.WorkspaceId == workspaceId && u.Role == UserRole.Employee)
            .OrderBy(u => u.Name);

        var result = await PaginationHelper.ToPagedResultAsync(q, query.SafePage, query.SafeLimit,
            u => mapper.Map<EmployeeResponseDto>(u));

        return Result<PagedResult<EmployeeResponseDto>>.Success(result);
    }

    public async Task<Result<EmployeeResponseDto>> UpdateEmployeeAsync(
        Guid workspaceId, Guid userId, UpdateEmployeeDto dto)
    {
        var user = await db.Users
            .FirstOrDefaultAsync(u => u.Id == userId && u.WorkspaceId == workspaceId && u.Role == UserRole.Employee);

        if (user is null)
            return Result<EmployeeResponseDto>.Failure(ApiError.NotFound("Employee not found."));

        return await ApplyUserUpdate(user, dto);
    }

    public async Task<Result<EmployeeResponseDto>> UpdateOwnerAsync(Guid userId, UpdateEmployeeDto dto)
    {
        var user = await db.Users
            .FirstOrDefaultAsync(u => u.Id == userId && u.Role == UserRole.Owner);

        if (user is null)
            return Result<EmployeeResponseDto>.Failure(ApiError.NotFound("Owner not found."));

        return await ApplyUserUpdate(user, dto);
    }

    public async Task<Result> SoftDeleteEmployeeAsync(Guid workspaceId, Guid employeeId, Guid deletedBy)
    {
        var employee = await db.Users
            .FirstOrDefaultAsync(u =>
                u.Id == employeeId &&
                u.WorkspaceId == workspaceId &&
                u.Role == UserRole.Employee);

        if (employee is null)
            return Result.Failure(ApiError.NotFound("Employee not found."));

        employee.IsDeleted = true;
        employee.DeletedAt = DateTime.UtcNow;
        employee.DeletedBy = deletedBy;
        await db.SaveChangesAsync();

        return Result.Success();
    }

    // ── Private ───────────────────────────────────────────────────────────────

    private async Task<Result<EmployeeResponseDto>> ApplyUserUpdate(User user, UpdateEmployeeDto dto)
    {
        if (!string.IsNullOrWhiteSpace(dto.Name))
            user.Name = dto.Name;

        if (!string.IsNullOrWhiteSpace(dto.NewPassword))
        {
            // Require current password verification when updating own password
            if (!string.IsNullOrWhiteSpace(dto.CurrentPassword) &&
                !BCrypt.Net.BCrypt.Verify(dto.CurrentPassword, user.PasswordHash))
            {
                return Result<EmployeeResponseDto>.Failure(
                    ApiError.BadRequest("Current password is incorrect."));
            }
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.NewPassword);
        }

        await db.SaveChangesAsync();
        return Result<EmployeeResponseDto>.Success(mapper.Map<EmployeeResponseDto>(user));
    }
}
