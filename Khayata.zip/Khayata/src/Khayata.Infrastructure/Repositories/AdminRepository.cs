using AutoMapper;
using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Admin;
using Khayata.Application.Interfaces;
using Khayata.Domain.Entities;
using Khayata.Domain.Enums;
using Khayata.Infrastructure.Data;
using Khayata.Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;

namespace Khayata.Infrastructure.Repositories;

public sealed class AdminRepository(AppDbContext db, IMapper mapper) : IAdminRepository
{
    // ── Workspace management ──────────────────────────────────────────────────
    public async Task<Result<PagedResult<WorkspaceSummaryDto>>> GetWorkspacesAsync(
        string? status, Application.Common.Models.PaginationQuery query)
    {
        var q = db.Workspaces
            .Include(w => w.Users)
            .Include(w => w.Orders)
            .Include(w => w.Customers)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(status) &&
            Enum.TryParse<WorkspaceStatus>(status, true, out var s))
            q = q.Where(w => w.Status == s);

        q = q.OrderByDescending(w => w.CreatedAt);

        var result = await PaginationHelper.ToPagedResultAsync(
            q, query.SafePage, query.SafeLimit,
            w => mapper.Map<WorkspaceSummaryDto>(w));

        return Result<PagedResult<WorkspaceSummaryDto>>.Success(result);
    }

    public async Task<Result<WorkspaceSummaryDto>> GetWorkspaceAsync(Guid workspaceId)
    {
        var ws = await db.Workspaces
            .Include(w => w.Users)
            .Include(w => w.Orders)
            .Include(w => w.Customers)
            .FirstOrDefaultAsync(w => w.Id == workspaceId);

        return ws is null
            ? Result<WorkspaceSummaryDto>.Failure(ApiError.NotFound("Workspace not found."))
            : Result<WorkspaceSummaryDto>.Success(mapper.Map<WorkspaceSummaryDto>(ws));
    }

    public async Task<Result<WorkspaceSummaryDto>> UpdateWorkspaceStatusAsync(
        Guid workspaceId, AdminUpdateWorkspaceStatusDto dto)
    {
        var ws = await db.Workspaces.FindAsync(workspaceId);
        if (ws is null)
            return Result<WorkspaceSummaryDto>.Failure(ApiError.NotFound("Workspace not found."));

        if (!Enum.TryParse<WorkspaceStatus>(dto.Status, true, out var newStatus))
            return Result<WorkspaceSummaryDto>.Failure(
                ApiError.BadRequest($"'{dto.Status}' is not a valid workspace status."));

        ws.Status = newStatus;

        if (newStatus == WorkspaceStatus.Active)
        {
            ws.LastActivatedAt    = DateTime.UtcNow;
            ws.NextSuspensionDate = DateTime.UtcNow.AddDays(30);
        }

        await db.SaveChangesAsync();

        // Log the action
        db.AuditLogs.Add(new AuditLog
        {
            Action     = $"WorkspaceStatus{newStatus}",
            EntityType = "Workspace",
            EntityId   = workspaceId,
            Details    = dto.Reason
        });
        await db.SaveChangesAsync();

        return await GetWorkspaceAsync(workspaceId);
    }

    // ── System-wide user views ────────────────────────────────────────────────
    public async Task<Result<PagedResult<SystemUserDto>>> GetAllUsersAsync(
        Guid? workspaceId, string? role, Application.Common.Models.PaginationQuery query)
    {
        // IgnoreQueryFilters: admin sees soft-deleted users too
        var q = db.Users
            .IgnoreQueryFilters()
            .Include(u => u.Workspace)
            .AsQueryable();

        if (workspaceId.HasValue) q = q.Where(u => u.WorkspaceId == workspaceId.Value);
        if (!string.IsNullOrWhiteSpace(role) && Enum.TryParse<UserRole>(role, true, out var r))
            q = q.Where(u => u.Role == r);

        q = q.OrderByDescending(u => u.CreatedAt);

        var result = await PaginationHelper.ToPagedResultAsync(
            q, query.SafePage, query.SafeLimit,
            u => mapper.Map<SystemUserDto>(u));

        return Result<PagedResult<SystemUserDto>>.Success(result);
    }

    public async Task<Result<SystemUserDto>> GetUserAsync(Guid userId)
    {
        var user = await db.Users
            .IgnoreQueryFilters()
            .Include(u => u.Workspace)
            .FirstOrDefaultAsync(u => u.Id == userId);

        return user is null
            ? Result<SystemUserDto>.Failure(ApiError.NotFound("User not found."))
            : Result<SystemUserDto>.Success(mapper.Map<SystemUserDto>(user));
    }

    public async Task<Result> AdminResetPasswordAsync(Guid userId, AdminResetPasswordDto dto)
    {
        var user = await db.Users.IgnoreQueryFilters()
            .FirstOrDefaultAsync(u => u.Id == userId);

        if (user is null) return Result.Failure(ApiError.NotFound("User not found."));

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.NewPassword);
        await db.SaveChangesAsync();

        db.AuditLogs.Add(new AuditLog { Action = "PasswordReset", EntityType = "User", EntityId = userId });
        await db.SaveChangesAsync();

        return Result.Success();
    }

    public async Task<Result> AdminSoftDeleteUserAsync(Guid userId, Guid adminId)
    {
        var user = await db.Users.IgnoreQueryFilters()
            .FirstOrDefaultAsync(u => u.Id == userId);
        if (user is null) return Result.Failure(ApiError.NotFound("User not found."));
        if (user.Role == UserRole.Owner)
            return Result.Failure(ApiError.Forbidden("Workspace owners cannot be deleted this way. Suspend the workspace instead."));

        user.IsDeleted = true;
        user.DeletedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return Result.Success();
    }

    public async Task<Result> AdminRestoreUserAsync(Guid userId)
    {
        var user = await db.Users.IgnoreQueryFilters()
            .FirstOrDefaultAsync(u => u.Id == userId);
        if (user is null) return Result.Failure(ApiError.NotFound("User not found."));

        user.IsDeleted = false;
        user.DeletedAt = null;
        user.DeletedBy = null;
        await db.SaveChangesAsync();
        return Result.Success();
    }

    // ── System-wide orders ────────────────────────────────────────────────────
    public async Task<Result<PagedResult<SystemOrderDto>>> GetAllOrdersAsync(
        Guid? workspaceId, string? status, Application.Common.Models.PaginationQuery query)
    {
        var q = db.Orders
            .Include(o => o.Workspace)
            .Include(o => o.Customer)
            .Include(o => o.CreatedBy)
            .AsQueryable();

        if (workspaceId.HasValue) q = q.Where(o => o.WorkspaceId == workspaceId.Value);
        if (!string.IsNullOrWhiteSpace(status) &&
            Enum.TryParse<OrderStatus>(status, true, out var s))
            q = q.Where(o => o.Status == s);

        q = q.OrderByDescending(o => o.CreatedAt);

        var result = await PaginationHelper.ToPagedResultAsync(
            q, query.SafePage, query.SafeLimit,
            o => mapper.Map<SystemOrderDto>(o));

        return Result<PagedResult<SystemOrderDto>>.Success(result);
    }

    // ── Statistics ────────────────────────────────────────────────────────────
    public async Task<Result<SystemStatsDto>> GetSystemStatsAsync()
    {
        var stats = new SystemStatsDto(
            TotalWorkspaces    : await db.Workspaces.CountAsync(),
            ActiveWorkspaces   : await db.Workspaces.CountAsync(w => w.Status == WorkspaceStatus.Active),
            PendingWorkspaces  : await db.Workspaces.CountAsync(w => w.Status == WorkspaceStatus.PendingActivation),
            SuspendedWorkspaces: await db.Workspaces.CountAsync(w => w.Status == WorkspaceStatus.Suspended),
            TotalUsers         : await db.Users.IgnoreQueryFilters().CountAsync(),
            TotalCustomers     : await db.Customers.IgnoreQueryFilters().CountAsync(),
            TotalOrders        : await db.Orders.CountAsync(),
            TotalRevenue       : await db.Orders.SumAsync(o => o.TotalPrice),
            TotalPaid          : await db.Orders.SumAsync(o => o.AmountPaid)
        );
        return Result<SystemStatsDto>.Success(stats);
    }

    public async Task<Result<WorkspaceStatsDto>> GetWorkspaceStatsAsync(Guid workspaceId)
    {
        var ws = await db.Workspaces.FindAsync(workspaceId);
        if (ws is null) return Result<WorkspaceStatsDto>.Failure(ApiError.NotFound("Workspace not found."));

        var orders = db.Orders.Where(o => o.WorkspaceId == workspaceId);

        var stats = new WorkspaceStatsDto(
            WorkspaceId    : workspaceId,
            WorkspaceName  : ws.Name,
            TotalOrders    : await orders.CountAsync(),
            PendingOrders  : await orders.CountAsync(o => o.Status == OrderStatus.Pending),
            CompletedOrders: await orders.CountAsync(o => o.Status == OrderStatus.Completed),
            DeliveredOrders: await orders.CountAsync(o => o.Status == OrderStatus.Delivered),
            TotalCustomers : await db.Customers.CountAsync(c => c.WorkspaceId == workspaceId),
            TotalEmployees : await db.Users.CountAsync(u => u.WorkspaceId == workspaceId && u.Role == UserRole.Employee),
            TotalRevenue   : await orders.SumAsync(o => o.TotalPrice),
            TotalPaid      : await orders.SumAsync(o => o.AmountPaid),
            Outstanding    : await orders.SumAsync(o => o.TotalPrice - o.AmountPaid)
        );

        return Result<WorkspaceStatsDto>.Success(stats);
    }

    // ── Audit logs ────────────────────────────────────────────────────────────
    public async Task<Result<PagedResult<AuditLogDto>>> GetAuditLogsAsync(
        Guid? entityId, string? entityType, Application.Common.Models.PaginationQuery query)
    {
        var q = db.AuditLogs.AsQueryable();
        if (entityId.HasValue)    q = q.Where(a => a.EntityId == entityId.Value);
        if (!string.IsNullOrWhiteSpace(entityType)) q = q.Where(a => a.EntityType == entityType);
        q = q.OrderByDescending(a => a.Timestamp);

        var result = await PaginationHelper.ToPagedResultAsync(
            q, query.SafePage, query.SafeLimit,
            a => mapper.Map<AuditLogDto>(a));
        return Result<PagedResult<AuditLogDto>>.Success(result);
    }

    public async Task LogAsync(AuditLog entry)
    {
        db.AuditLogs.Add(entry);
        await db.SaveChangesAsync();
    }
}
