using AutoMapper;
using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Order;
using Khayata.Application.Interfaces;
using Khayata.Domain.Entities;
using Khayata.Domain.Enums;
using Khayata.Infrastructure.Data;
using Khayata.Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;

namespace Khayata.Infrastructure.Repositories;

public sealed class OrderRepository(AppDbContext db, IMapper mapper) : IOrderRepository
{
    public async Task<Result<OrderResponseDto>> CreateAsync(
        Guid workspaceId, Guid createdById, CreateOrderDto dto)
    {
        var customer = await db.Customers
            .FirstOrDefaultAsync(c => c.Id == dto.CustomerId && c.WorkspaceId == workspaceId);
        if (customer is null)
            return Result<OrderResponseDto>.Failure(ApiError.NotFound("Customer not found."));

        // Validate creator belongs to workspace
        var creatorExists = await db.Users
            .AnyAsync(u => u.Id == createdById && u.WorkspaceId == workspaceId);
        if (!creatorExists)
            return Result<OrderResponseDto>.Failure(ApiError.Forbidden("User does not belong to this workspace."));

        if (dto.AmountPaid < 0 || dto.AmountPaid > dto.TotalPrice)
            return Result<OrderResponseDto>.Failure(
                ApiError.UnprocessableEntity("Amount paid cannot be negative or exceed the total price."));

        var order = new Order
        {
            WorkspaceId  = workspaceId,
            CustomerId   = dto.CustomerId,
            CreatedById  = createdById,
            CreatedBy    = createdById,   // audit
            Description  = dto.Description,
            TotalPrice   = dto.TotalPrice,
            AmountPaid   = dto.AmountPaid,
            DeliveryDate = dto.DeliveryDate
        };

        db.Orders.Add(order);
        await db.SaveChangesAsync();

        return await GetByIdAsync(workspaceId, order.Id);
    }

    public async Task<Result<OrderResponseDto>> GetByIdAsync(Guid workspaceId, Guid orderId)
    {
        var order = await LoadOrder(workspaceId, orderId);
        return order is null
            ? Result<OrderResponseDto>.Failure(ApiError.NotFound("Order not found."))
            : Result<OrderResponseDto>.Success(mapper.Map<OrderResponseDto>(order));
    }

    public async Task<Result<OrderResponseDto>> UpdateAsync(
        Guid workspaceId, Guid orderId, Guid updatedBy, UpdateOrderDto dto)
    {
        var order = await LoadOrder(workspaceId, orderId);
        if (order is null)
            return Result<OrderResponseDto>.Failure(ApiError.NotFound("Order not found."));

        // Status transition
        if (!string.IsNullOrWhiteSpace(dto.Status))
        {
            if (!Enum.TryParse<OrderStatus>(dto.Status, true, out var newStatus))
                return Result<OrderResponseDto>.Failure(
                    ApiError.BadRequest($"'{dto.Status}' is not a valid order status."));

            if (!OrderStatusRules.CanTransition(order.Status, newStatus))
                return Result<OrderResponseDto>.Failure(
                    ApiError.UnprocessableEntity(
                        $"Cannot transition from {order.Status} to {newStatus}."));

            order.Status = newStatus;
        }

        if (!string.IsNullOrWhiteSpace(dto.Description))
            order.Description = dto.Description;

        if (dto.TotalPrice.HasValue)
        {
            if (dto.TotalPrice.Value < 0.01m)
                return Result<OrderResponseDto>.Failure(
                    ApiError.BadRequest("Total price must be greater than zero."));
            order.TotalPrice = dto.TotalPrice.Value;
        }

        if (dto.AmountPaid.HasValue)
        {
            if (dto.AmountPaid.Value < 0 || dto.AmountPaid.Value > order.TotalPrice)
                return Result<OrderResponseDto>.Failure(
                    ApiError.UnprocessableEntity("Amount paid cannot be negative or exceed the total price."));
            order.AmountPaid = dto.AmountPaid.Value;
        }

        if (dto.DeliveryDate.HasValue)
            order.DeliveryDate = dto.DeliveryDate.Value;

        order.UpdatedBy = updatedBy;
        await db.SaveChangesAsync();

        return Result<OrderResponseDto>.Success(mapper.Map<OrderResponseDto>(order));
    }

    public async Task<Result<PagedResult<OrderResponseDto>>> ListAsync(
        Guid workspaceId, Guid requestingUserId, string role, OrderQuery query)
    {
        var q = db.Orders
            .Include(o => o.Customer).ThenInclude(c => c.Phones)
            .Include(o => o.CreatedBy)
            .Where(o => o.WorkspaceId == workspaceId);

        // Employees can only see orders they created
        if (role == UserRole.Employee.ToString())
            q = q.Where(o => o.CreatedById == requestingUserId);
        else if (query.MyOrders)
            q = q.Where(o => o.CreatedById == requestingUserId);

        if (!string.IsNullOrWhiteSpace(query.Status) &&
            Enum.TryParse<OrderStatus>(query.Status, true, out var statusFilter))
            q = q.Where(o => o.Status == statusFilter);

        if (query.CustomerId.HasValue)
            q = q.Where(o => o.CustomerId == query.CustomerId.Value);

        q = q.OrderByDescending(o => o.CreatedAt);

        var result = await PaginationHelper.ToPagedResultAsync(
            q, query.Page, Math.Clamp(query.Limit, 1, 100),
            o => mapper.Map<OrderResponseDto>(o));

        return Result<PagedResult<OrderResponseDto>>.Success(result);
    }

    private Task<Order?> LoadOrder(Guid workspaceId, Guid orderId) =>
        db.Orders
            .Include(o => o.Customer).ThenInclude(c => c.Phones)
            .Include(o => o.CreatedBy)
            .FirstOrDefaultAsync(o => o.Id == orderId && o.WorkspaceId == workspaceId);
}
