using AutoMapper;
using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Auth;
using Khayata.Application.Interfaces;
using Khayata.Domain.Entities;
using Khayata.Domain.Enums;
using Khayata.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Khayata.Infrastructure.Repositories;

public sealed class AuthRepository(
    AppDbContext   db,
    ITokenService  tokenService,
    IMapper        mapper) : IAuthRepository
{
    public async Task<Result<RegisterResponseDto>> RegisterOwnerAsync(RegisterOwnerDto dto)
    {
        try
        {
            var phoneExists = await db.Users
                .IgnoreQueryFilters()
                .AnyAsync(u => u.Phone == dto.Phone && u.Role == UserRole.Owner);

            if (phoneExists)
                return Result<RegisterResponseDto>.Failure(
                    ApiError.Conflict("An owner account with this phone number already exists."));

            var workspace = new Workspace { Name = dto.WorkspaceName };
            var owner = new User
            {
                WorkspaceId  = workspace.Id,
                Name         = dto.Name,
                Phone        = dto.Phone,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                Role         = UserRole.Owner,
                CreatedBy    = null // bootstrapped — no actor yet
            };
            workspace.Users.Add(owner);
            // Set audit FK after we have the ID
            workspace.CreatedBy = owner.Id;

            db.Workspaces.Add(workspace);
            await db.SaveChangesAsync();

            return Result<RegisterResponseDto>.Success(new RegisterResponseDto(
                "Registration submitted. Your account is pending admin activation.",
                mapper.Map<UserResponseDto>(owner),
                mapper.Map<WorkspaceResponseDto>(workspace)));
        }
        catch (DbUpdateException)
        {
            return Result<RegisterResponseDto>.Failure(ApiError.Internal("A database error occurred."));
        }
    }

    public async Task<Result<AuthResponseDto>> LoginAsync(LoginDto dto)
    {
        var user = await db.Users
            .IgnoreQueryFilters()     // allow soft-deleted check so we give a meaningful error
            .Include(u => u.Workspace)
            .FirstOrDefaultAsync(u => u.Phone == dto.Phone);

        if (user is null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
            return Result<AuthResponseDto>.Failure(
                ApiError.Unauthorized("Invalid phone number or password."));

        if (user.IsDeleted)
            return Result<AuthResponseDto>.Failure(
                ApiError.Forbidden("This account has been deactivated."));

        return user.Workspace.Status switch
        {
            Khayata.Domain.Enums.WorkspaceStatus.PendingActivation =>
                Result<AuthResponseDto>.Failure(
                    ApiError.Forbidden("Your workspace is awaiting admin activation.")),

            Khayata.Domain.Enums.WorkspaceStatus.Suspended =>
                Result<AuthResponseDto>.Failure(
                    ApiError.Forbidden("Your workspace has been suspended. Please contact support.")),

            _ => Result<AuthResponseDto>.Success(new AuthResponseDto(
                    tokenService.GenerateToken(user),
                    "Bearer",
                    tokenService.ExpiresInSeconds,
                    mapper.Map<UserResponseDto>(user),
                    mapper.Map<WorkspaceResponseDto>(user.Workspace)))
        };
    }

    public async Task<Result<UserResponseDto>> CreateEmployeeAsync(Guid workspaceId, CreateEmployeeDto dto)
    {
        var phoneExists = await db.Users
            .AnyAsync(u => u.WorkspaceId == workspaceId && u.Phone == dto.Phone);

        if (phoneExists)
            return Result<UserResponseDto>.Failure(
                ApiError.Conflict("An employee with this phone number already exists in your workspace."));

        var employee = new User
        {
            WorkspaceId  = workspaceId,
            Name         = dto.Name,
            Phone        = dto.Phone,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
            Role         = UserRole.Employee
        };

        db.Users.Add(employee);
        await db.SaveChangesAsync();

        return Result<UserResponseDto>.Success(mapper.Map<UserResponseDto>(employee));
    }
}
