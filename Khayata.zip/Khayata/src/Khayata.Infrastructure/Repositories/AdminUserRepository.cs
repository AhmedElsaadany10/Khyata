using AutoMapper;
using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Admin;
using Khayata.Application.Interfaces;
using Khayata.Domain.Entities;
using Khayata.Infrastructure.Data;
using Khayata.Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;

namespace Khayata.Infrastructure.Repositories;

public sealed class AdminUserRepository(
    AppDbContext  db,
    ITokenService tokenService,
    IMapper       mapper) : IAdminUserRepository
{
    public Task<AdminUser?> FindByUsernameAsync(string username) =>
        db.AdminUsers.FirstOrDefaultAsync(a => a.Username == username);

    public Task<AdminUser?> FindByIdAsync(Guid id) =>
        db.AdminUsers.FindAsync(id).AsTask();

    public async Task<Result<AdminAuthResponseDto>> LoginAsync(AdminLoginDto dto)
    {
        var admin = await FindByUsernameAsync(dto.Username);

        if (admin is null || !BCrypt.Net.BCrypt.Verify(dto.Password, admin.PasswordHash))
            return Result<AdminAuthResponseDto>.Failure(
                ApiError.Unauthorized("Invalid username or password."));

        if (!admin.IsActive)
            return Result<AdminAuthResponseDto>.Failure(
                ApiError.Forbidden("This admin account has been deactivated."));

        return Result<AdminAuthResponseDto>.Success(new AdminAuthResponseDto(
            tokenService.GenerateAdminToken(admin),
            "Bearer",
            tokenService.ExpiresInSeconds,
            mapper.Map<AdminUserDto>(admin)));
    }

    public async Task<Result<AdminUserDto>> CreateAsync(CreateAdminUserDto dto)
    {
        var exists = await db.AdminUsers.AnyAsync(a => a.Username == dto.Username);
        if (exists)
            return Result<AdminUserDto>.Failure(
                ApiError.Conflict("An admin user with this username already exists."));

        var validRoles = new[] { "SuperAdmin", "Moderator" };
        if (!validRoles.Contains(dto.Role))
            return Result<AdminUserDto>.Failure(
                ApiError.BadRequest($"Role must be one of: {string.Join(", ", validRoles)}."));

        var admin = new AdminUser
        {
            Username     = dto.Username,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
            Role         = dto.Role
        };

        db.AdminUsers.Add(admin);
        await db.SaveChangesAsync();

        return Result<AdminUserDto>.Success(mapper.Map<AdminUserDto>(admin));
    }

    public async Task<Result<PagedResult<AdminUserDto>>> ListAsync(
        Application.Common.Models.PaginationQuery query)
    {
        var q = db.AdminUsers.OrderBy(a => a.Username);
        var result = await PaginationHelper.ToPagedResultAsync(
            q, query.SafePage, query.SafeLimit,
            a => mapper.Map<AdminUserDto>(a));
        return Result<PagedResult<AdminUserDto>>.Success(result);
    }
}
