using Khayata.Domain.Enums;
using Khayata.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Khayata.Infrastructure.BackgroundServices;

/// <summary>
/// Runs every hour and suspends any Active workspace whose NextSuspensionDate has passed.
/// The 30-day clock starts when an admin activates (or reactivates) the workspace.
/// Only an admin can reactivate a suspended workspace.
/// </summary>
public sealed class WorkspaceSuspensionService(
    IServiceScopeFactory scopeFactory,
    ILogger<WorkspaceSuspensionService> logger) : BackgroundService
{
    // Check every hour — no need to run more often
    private static readonly TimeSpan CheckInterval = TimeSpan.FromHours(1);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        logger.LogInformation("WorkspaceSuspensionService started.");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await SuspendExpiredWorkspacesAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error while checking workspace suspensions.");
            }

            await Task.Delay(CheckInterval, stoppingToken);
        }
    }

    private async Task SuspendExpiredWorkspacesAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var expired = await db.Workspaces
            .Where(w =>
                w.Status            == WorkspaceStatus.Active &&
                w.NextSuspensionDate != null &&
                w.NextSuspensionDate <= DateTime.UtcNow)
            .ToListAsync(ct);

        if (expired.Count == 0) return;

        logger.LogInformation("Suspending {Count} workspace(s) due to subscription expiry.", expired.Count);

        foreach (var ws in expired)
        {
            ws.Status             = WorkspaceStatus.Suspended;
            ws.NextSuspensionDate = null;

            db.AuditLogs.Add(new Domain.Entities.AuditLog
            {
                Action     = "WorkspaceAutoSuspended",
                EntityType = "Workspace",
                EntityId   = ws.Id,
                Details    = "Suspended automatically after 30-day period expired."
            });

            logger.LogInformation("Workspace {Id} ({Name}) suspended.", ws.Id, ws.Name);
        }

        await db.SaveChangesAsync(ct);
    }
}
