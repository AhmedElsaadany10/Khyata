using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Khayata.Application.Interfaces;
using Khayata.Domain.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Khayata.Infrastructure.Services;

public sealed class TokenService(IConfiguration config) : ITokenService
{
    private readonly JwtSecurityTokenHandler _handler = new();

    public int ExpiresInSeconds =>
        int.Parse(config["Jwt:ExpiresInMinutes"] ?? "60") * 60;

    /// <summary>Issues a workspace-scoped JWT for owners and employees.</summary>
    public string GenerateToken(User user)
    {
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim("wid",   user.WorkspaceId.ToString()),
            new Claim("role",  user.Role.ToString()),
            new Claim("type",  "workspace"),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };
        return BuildToken(claims);
    }

    /// <summary>Issues an admin-scoped JWT with a separate audience to prevent cross-use.</summary>
    public string GenerateAdminToken(AdminUser adminUser)
    {
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, adminUser.Id.ToString()),
            new Claim("role",  adminUser.Role),
            new Claim("type",  "admin"),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };
        return BuildToken(claims, audience: config["Jwt:AdminAudience"]);
    }

    private string BuildToken(Claim[] claims, string? audience = null)
    {
        var key   = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer:             config["Jwt:Issuer"],
            audience:           audience ?? config["Jwt:Audience"],
            claims:             claims,
            expires:            DateTime.UtcNow.AddSeconds(ExpiresInSeconds),
            signingCredentials: creds);

        return _handler.WriteToken(token);
    }
}
