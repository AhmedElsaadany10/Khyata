namespace Khayata.Domain.Common;

/// <summary>
/// Base class for all entities that need audit tracking.
/// CreatedBy / UpdatedBy store the User.Id who performed the action.
/// </summary>
public abstract class AuditableEntity
{
    public Guid      Id        { get; set; } = Guid.NewGuid();
    public DateTime  CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime  UpdatedAt { get; set; } = DateTime.UtcNow;
    public Guid?     CreatedBy { get; set; }
    public Guid?     UpdatedBy { get; set; }
}

/// <summary>
/// Extends AuditableEntity with soft-delete support.
/// EF Core global query filters automatically exclude IsDeleted = true rows.
/// </summary>
public abstract class SoftDeletableEntity : AuditableEntity
{
    public bool      IsDeleted { get; set; } = false;
    public DateTime? DeletedAt { get; set; }
    public Guid?     DeletedBy { get; set; }
}
