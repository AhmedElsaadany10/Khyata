using Khayata.Domain.Common;
using Khayata.Domain.Enums;

namespace Khayata.Domain.Entities;

// ─────────────────────────────────────────────────────────────────────────────
// Workspace
// ─────────────────────────────────────────────────────────────────────────────
public class Workspace : AuditableEntity
{
    public string          Name                   { get; set; } = string.Empty;
    public WorkspaceStatus Status                 { get; set; } = WorkspaceStatus.PendingActivation;

    /// <summary>UTC timestamp of the last activation. Used by the suspension background service.</summary>
    public DateTime?       LastActivatedAt        { get; set; }

    /// <summary>Next scheduled suspension date (set when workspace is activated).</summary>
    public DateTime?       NextSuspensionDate     { get; set; }

    public ICollection<User>     Users     { get; set; } = [];
    public ICollection<Customer> Customers { get; set; } = [];
    public ICollection<Order>    Orders    { get; set; } = [];
}

// ─────────────────────────────────────────────────────────────────────────────
// User (Owner + Employee — role discriminated)
// ─────────────────────────────────────────────────────────────────────────────
public class User : SoftDeletableEntity
{
    public Guid     WorkspaceId  { get; set; }
    public string   Name         { get; set; } = string.Empty;
    public string   Phone        { get; set; } = string.Empty;
    public string   PasswordHash { get; set; } = string.Empty;
    public UserRole Role         { get; set; }

    public Workspace       Workspace     { get; set; } = null!;
    public ICollection<Order> CreatedOrders { get; set; } = [];
}

// ─────────────────────────────────────────────────────────────────────────────
// Customer
// ─────────────────────────────────────────────────────────────────────────────
public class Customer : SoftDeletableEntity
{
    public Guid   WorkspaceId { get; set; }
    public string Name        { get; set; } = string.Empty;

    public Workspace                  Workspace    { get; set; } = null!;
    public Measurements?              Measurements { get; set; }
    public ICollection<CustomerPhone> Phones       { get; set; } = [];
    public ICollection<Order>         Orders       { get; set; } = [];
}

/// <summary>
/// Supports multiple phone numbers per customer.
/// One phone is marked as primary.
/// </summary>
public class CustomerPhone : AuditableEntity
{
    public Guid   CustomerId  { get; set; }
    public Guid   WorkspaceId { get; set; }
    public string Number      { get; set; } = string.Empty;
    public bool   IsPrimary   { get; set; } = false;

    public Customer Customer { get; set; } = null!;
}

// ─────────────────────────────────────────────────────────────────────────────
// Measurements
// ─────────────────────────────────────────────────────────────────────────────
public class Measurements : AuditableEntity
{
    public Guid     CustomerId  { get; set; }
    public Guid     WorkspaceId { get; set; }
    public decimal? Height      { get; set; }
    public decimal? Sleeve      { get; set; }
    public decimal? ChestWidth  { get; set; }
    public decimal? Shoulder    { get; set; }
    public decimal? Neck        { get; set; }

    public Customer Customer { get; set; } = null!;
}

// ─────────────────────────────────────────────────────────────────────────────
// Order
// ─────────────────────────────────────────────────────────────────────────────
public class Order : AuditableEntity
{
    public Guid        WorkspaceId  { get; set; }
    public Guid        CustomerId   { get; set; }

    /// <summary>
    /// Replaces AssignedTo. Tracks which user (Owner or Employee) created this order.
    /// Populated automatically from the JWT on creation.
    /// </summary>
    public Guid        CreatedById  { get; set; }

    public string      Description  { get; set; } = string.Empty;
    public decimal     TotalPrice   { get; set; }
    public decimal     AmountPaid   { get; set; }

    /// <summary>Computed property — never stored in the database.</summary>
    public decimal     RemainingBalance => TotalPrice - AmountPaid;

    public OrderStatus Status       { get; set; } = OrderStatus.Pending;
    public DateTime    DeliveryDate { get; set; }

    public Workspace Workspace { get; set; } = null!;
    public Customer  Customer  { get; set; } = null!;
    public User      CreatedBy { get; set; } = null!;  // navigation for the creator
}
