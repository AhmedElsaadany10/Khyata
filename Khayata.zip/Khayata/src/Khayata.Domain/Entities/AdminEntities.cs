using Khayata.Domain.Common;

namespace Khayata.Domain.Entities;

/// <summary>
/// Completely separate from workspace User entities.
/// Stored in the same DB but authenticated via a distinct JWT audience.
/// </summary>
public class AdminUser : AuditableEntity
{
    public string Username     { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string Role         { get; set; } = "SuperAdmin"; // "SuperAdmin" | "Moderator"
    public bool   IsActive     { get; set; } = true;
}

/// <summary>
/// Append-only audit trail. Never deleted.
/// Written by repositories and the admin layer whenever a significant action occurs.
/// </summary>
public class AuditLog
{
    public Guid      Id         { get; set; } = Guid.NewGuid();
    public Guid?     UserId     { get; set; }    // workspace user or admin user
    public string?   UserName   { get; set; }
    public string    Action     { get; set; } = string.Empty; // e.g. "WorkspaceActivated"
    public string    EntityType { get; set; } = string.Empty; // e.g. "Workspace"
    public Guid?     EntityId   { get; set; }
    public DateTime  Timestamp  { get; set; } = DateTime.UtcNow;
    public string?   Details    { get; set; }    // JSON or free text
}
