namespace Khayata.Domain.Enums;

public enum WorkspaceStatus
{
    PendingActivation,
    Active,
    Suspended
}

public enum UserRole
{
    Owner,
    Employee
}

public enum OrderStatus
{
    Pending,
    Completed,
    Delivered,
    Delayed,
    Cancelled
}
