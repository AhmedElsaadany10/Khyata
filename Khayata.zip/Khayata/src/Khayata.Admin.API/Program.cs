using System.Text;
using Khayata.Application.Common.Mappings;
using Khayata.Application.Interfaces;
using Khayata.Infrastructure.Data;
using Khayata.Infrastructure.Repositories;
using Khayata.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// ── Shared DB ─────────────────────────────────────────────────────────────────
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("Default")));

// ── AutoMapper ────────────────────────────────────────────────────────────────
builder.Services.AddAutoMapper(typeof(MappingProfile));

// ── JWT Authentication (admin audience — prevents workspace tokens being used here) ──
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = Encoding.UTF8.GetBytes(jwtSettings["Key"]!);

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(opt =>
    {
        opt.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer           = true,
            ValidateAudience         = true,
            ValidateLifetime         = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer              = jwtSettings["Issuer"],
            ValidAudience            = jwtSettings["AdminAudience"],  // separate audience
            IssuerSigningKey         = new SymmetricSecurityKey(key),
            ClockSkew                = TimeSpan.Zero
        };
    });

// ── RBAC Policies ─────────────────────────────────────────────────────────────
builder.Services.AddAuthorization(options =>
{
    // Any valid admin token (SuperAdmin or Moderator)
    options.AddPolicy("AdminAccess", policy =>
        policy.RequireAuthenticatedUser()
              .RequireClaim("type", "admin"));

    // Only SuperAdmin — for destructive operations (delete, password reset, etc.)
    options.AddPolicy("SuperAdminOnly", policy =>
        policy.RequireAuthenticatedUser()
              .RequireClaim("type", "admin")
              .RequireClaim("role", "SuperAdmin"));
});

// ── Repositories ──────────────────────────────────────────────────────────────
builder.Services.AddScoped<ITokenService,        TokenService>();
builder.Services.AddScoped<IAdminRepository,     AdminRepository>();
builder.Services.AddScoped<IAdminUserRepository, AdminUserRepository>();

// ── Controllers / Swagger ─────────────────────────────────────────────────────
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title       = "Khayata Admin API",
        Version     = "v1",
        Description = "Super-admin dashboard. Requires an admin-scoped JWT (POST /admin/auth/login)."
    });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name         = "Authorization",
        Type         = SecuritySchemeType.Http,
        Scheme       = "bearer",
        BearerFormat = "JWT",
        In           = ParameterLocation.Header
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            Array.Empty<string>()
        }
    });
});

builder.Services.AddCors(opt =>
    opt.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();
