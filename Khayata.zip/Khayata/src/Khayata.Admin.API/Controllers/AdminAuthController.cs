using Khayata.Application.DTOs.Admin;
using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.Admin.API.Controllers;

[ApiController]
[Route("admin/auth")]
public sealed class AdminAuthController(IAdminUserRepository adminUserRepo) : ControllerBase
{
    /// <summary>SuperAdmin / Moderator login. Issues an admin-scoped JWT.</summary>
    [HttpPost("login")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login([FromBody] AdminLoginDto dto)
    {
        var result = await adminUserRepo.LoginAsync(dto);
        if (!result.IsSuccess)
            return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }

    /// <summary>SuperAdmin only: create additional admin or moderator accounts.</summary>
    [HttpPost("users")]
    [Authorize(Policy = "SuperAdminOnly")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CreateAdminUser([FromBody] CreateAdminUserDto dto)
    {
        var result = await adminUserRepo.CreateAsync(dto);
        if (!result.IsSuccess)
            return StatusCode(result.Error!.Code, result.Error);
        return StatusCode(201, result.Value);
    }

    /// <summary>List all admin users.</summary>
    [HttpGet("users")]
    [Authorize(Policy = "SuperAdminOnly")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> ListAdminUsers(
        [FromQuery] int page = 1, [FromQuery] int limit = 20)
    {
        var result = await adminUserRepo.ListAsync(
            new Application.Common.Models.PaginationQuery { Page = page, Limit = limit });
        if (!result.IsSuccess)
            return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }
}
