using Khayata.Application.DTOs.Admin;
using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.Admin.API.Controllers;

[ApiController]
[Route("admin/users")]
[Authorize(Policy = "AdminAccess")]
public sealed class UsersAdminController(IAdminRepository adminRepo) : ControllerBase
{
    /// <summary>
    /// List all users across the entire system (includes soft-deleted).
    /// Filter by workspaceId and/or role (Owner | Employee).
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> List(
        [FromQuery] Guid?   workspaceId = null,
        [FromQuery] string? role        = null,
        [FromQuery] int     page        = 1,
        [FromQuery] int     limit       = 20)
    {
        var result = await adminRepo.GetAllUsersAsync(
            workspaceId, role,
            new Application.Common.Models.PaginationQuery { Page = page, Limit = limit });

        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }

    /// <summary>Get a single user by id (visible even if soft-deleted).</summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id)
    {
        var result = await adminRepo.GetUserAsync(id);
        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }

    /// <summary>Reset any user's password without knowing their current one.</summary>
    [HttpPatch("{id:guid}/reset-password")]
    [Authorize(Policy = "SuperAdminOnly")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> ResetPassword(Guid id, [FromBody] AdminResetPasswordDto dto)
    {
        var result = await adminRepo.AdminResetPasswordAsync(id, dto);
        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return NoContent();
    }

    /// <summary>Soft-delete a user (sets IsDeleted = true). Cannot delete workspace owners.</summary>
    [HttpDelete("{id:guid}")]
    [Authorize(Policy = "SuperAdminOnly")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> SoftDelete(Guid id)
    {
        var adminId = Guid.Parse(User.FindFirst("sub")!.Value);
        var result  = await adminRepo.AdminSoftDeleteUserAsync(id, adminId);
        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return NoContent();
    }

    /// <summary>Restore a previously soft-deleted user.</summary>
    [HttpPost("{id:guid}/restore")]
    [Authorize(Policy = "SuperAdminOnly")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Restore(Guid id)
    {
        var result = await adminRepo.AdminRestoreUserAsync(id);
        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return NoContent();
    }
}
