using Khayata.Application.DTOs.Admin;
using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.Admin.API.Controllers;

[ApiController]
[Route("admin/workspaces")]
[Authorize(Policy = "AdminAccess")]
public sealed class WorkspacesAdminController(IAdminRepository adminRepo) : ControllerBase
{
    /// <summary>
    /// List all workspaces across the system.
    /// Filter by status: PendingActivation | Active | Suspended
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> List(
        [FromQuery] string? status,
        [FromQuery] int     page  = 1,
        [FromQuery] int     limit = 20)
    {
        var result = await adminRepo.GetWorkspacesAsync(
            status,
            new Application.Common.Models.PaginationQuery { Page = page, Limit = limit });

        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }

    /// <summary>Get full details for a single workspace including stats.</summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id)
    {
        var result = await adminRepo.GetWorkspaceAsync(id);
        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }

    /// <summary>
    /// Update workspace status.
    /// Setting to Active resets the 30-day suspension clock.
    /// Only admins can reactivate a suspended workspace.
    /// </summary>
    [HttpPatch("{id:guid}/status")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateStatus(Guid id, [FromBody] AdminUpdateWorkspaceStatusDto dto)
    {
        var result = await adminRepo.UpdateWorkspaceStatusAsync(id, dto);
        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }

    /// <summary>Workspace-level stats: orders, revenue, employees, customers.</summary>
    [HttpGet("{id:guid}/stats")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetStats(Guid id)
    {
        var result = await adminRepo.GetWorkspaceStatsAsync(id);
        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }
}
