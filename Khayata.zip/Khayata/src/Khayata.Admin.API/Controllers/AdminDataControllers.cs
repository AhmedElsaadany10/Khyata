using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.Admin.API.Controllers;

[ApiController]
[Route("admin/orders")]
[Authorize(Policy = "AdminAccess")]
public sealed class OrdersAdminController(IAdminRepository adminRepo) : ControllerBase
{
    /// <summary>
    /// View all orders across the entire system.
    /// Filter by workspaceId and/or status.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> List(
        [FromQuery] Guid?   workspaceId = null,
        [FromQuery] string? status      = null,
        [FromQuery] int     page        = 1,
        [FromQuery] int     limit       = 20)
    {
        var result = await adminRepo.GetAllOrdersAsync(
            workspaceId, status,
            new Application.Common.Models.PaginationQuery { Page = page, Limit = limit });

        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }
}

// ─────────────────────────────────────────────────────────────────────────────

[ApiController]
[Route("admin/stats")]
[Authorize(Policy = "AdminAccess")]
public sealed class StatsAdminController(IAdminRepository adminRepo) : ControllerBase
{
    /// <summary>System-wide aggregate statistics: workspaces, users, orders, revenue.</summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetSystemStats()
    {
        var result = await adminRepo.GetSystemStatsAsync();
        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }
}

// ─────────────────────────────────────────────────────────────────────────────

[ApiController]
[Route("admin/audit-logs")]
[Authorize(Policy = "SuperAdminOnly")]
public sealed class AuditLogsAdminController(IAdminRepository adminRepo) : ControllerBase
{
    /// <summary>
    /// Query the audit log. Optionally filter by entity type and/or entity id.
    /// Returns newest entries first.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> List(
        [FromQuery] Guid?   entityId   = null,
        [FromQuery] string? entityType = null,
        [FromQuery] int     page       = 1,
        [FromQuery] int     limit      = 20)
    {
        var result = await adminRepo.GetAuditLogsAsync(
            entityId, entityType,
            new Application.Common.Models.PaginationQuery { Page = page, Limit = limit });

        if (!result.IsSuccess) return StatusCode(result.Error!.Code, result.Error);
        return Ok(result.Value);
    }
}
