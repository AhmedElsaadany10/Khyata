using Khayata.API.Extensions;
using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.API.Controllers;

[ApiController]
[Route("v1/workspaces")]
[Authorize]
public sealed class WorkspacesController(IWorkspaceRepository workspaceRepo) : ControllerBase
{
    /// <summary>Returns the current user's workspace details including subscription dates.</summary>
    [HttpGet("me")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetMyWorkspace()
    {
        var result = await workspaceRepo.GetMyWorkspaceAsync(User.GetWorkspaceId());
        return this.ToActionResult(result);
    }
}
