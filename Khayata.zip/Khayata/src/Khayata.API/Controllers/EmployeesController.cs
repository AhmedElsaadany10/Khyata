using Khayata.API.Extensions;
using Khayata.Application.Common.Models;
using Khayata.Application.DTOs.Employee;
using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.API.Controllers;

[ApiController]
[Route("v1/employees")]
[Authorize]
public sealed class EmployeesController(IUserRepository userRepo) : ControllerBase
{
    /// <summary>
    /// Owner: list all employees in the workspace (excludes soft-deleted by default).
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> List(
        [FromQuery] int page = 1,
        [FromQuery] int limit = 20)
    {
        if (User.GetRole() != "Owner")
            return StatusCode(403, Forbidden("Only owners can list employees."));

        var result = await userRepo.GetEmployeesAsync(
            User.GetWorkspaceId(),
            new PaginationQuery { Page = page, Limit = limit });

        return this.ToActionResult(result);
    }

    /// <summary>Owner: get a single employee by id.</summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id)
    {
        if (User.GetRole() != "Owner")
            return StatusCode(403, Forbidden("Only owners can view employee details."));

        var result = await userRepo.GetEmployeeByIdAsync(User.GetWorkspaceId(), id);
        return this.ToActionResult(result);
    }

    /// <summary>
    /// Owner: update an employee's name or password.
    /// Employee: update their own name or password (id must match the token sub).
    /// </summary>
    [HttpPatch("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateEmployeeDto dto)
    {
        var role = User.GetRole();

        // An employee can only update themselves
        if (role == "Employee" && User.GetUserId() != id)
            return StatusCode(403, Forbidden("Employees can only update their own profile."));

        var result = await userRepo.UpdateEmployeeAsync(User.GetWorkspaceId(), id, dto);
        return this.ToActionResult(result);
    }

    /// <summary>Owner: soft-delete an employee. Sets IsDeleted = true; never removes the row.</summary>
    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> SoftDelete(Guid id)
    {
        if (User.GetRole() != "Owner")
            return StatusCode(403, Forbidden("Only owners can deactivate employees."));

        var result = await userRepo.SoftDeleteEmployeeAsync(
            User.GetWorkspaceId(), id, User.GetUserId());

        return this.ToActionResult(result);
    }

    private static object Forbidden(string message) =>
        new { code = 403, status = "Forbidden", message };
}
