using Khayata.API.Extensions;
using Khayata.Application.DTOs.Order;
using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.API.Controllers;

[ApiController]
[Route("v1/orders")]
[Authorize]
public sealed class OrdersController(IOrderRepository orderRepo) : ControllerBase
{
    /// <summary>
    /// Create a new order. Available to both owners and employees.
    /// The creator is captured automatically from the JWT — no need to supply it.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
    public async Task<IActionResult> Create([FromBody] CreateOrderDto dto)
    {
        var result = await orderRepo.CreateAsync(
            User.GetWorkspaceId(), User.GetUserId(), dto);

        if (!result.IsSuccess) return this.ToActionResult(result);
        return CreatedAtAction(nameof(GetById), new { id = result.Value!.Id }, result.Value);
    }

    /// <summary>
    /// List orders with optional filters.
    /// Employees automatically see only the orders they created.
    /// Owners see all orders unless ?myOrders=true is passed.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> List([FromQuery] OrderQuery query)
    {
        var result = await orderRepo.ListAsync(
            User.GetWorkspaceId(),
            User.GetUserId(),
            User.GetRole(),
            query);
        return this.ToActionResult(result);
    }

    /// <summary>Get a single order with customer info and creator details.</summary>
    [HttpGet("{id:guid}", Name = nameof(GetById))]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id)
    {
        var result = await orderRepo.GetByIdAsync(User.GetWorkspaceId(), id);
        return this.ToActionResult(result);
    }

    /// <summary>
    /// Partially update an order.
    /// - Any field omitted (null) is left unchanged.
    /// - Status changes are validated against the transition rules.
    /// - Owners can update all fields; employees can only update status and payment.
    /// </summary>
    [HttpPatch("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateOrderDto dto)
    {
        // Employees may not edit description, price, or delivery date
        if (User.GetRole() == "Employee")
        {
            dto = dto with
            {
                Description  = null,
                TotalPrice   = null,
                DeliveryDate = null
            };
        }

        var result = await orderRepo.UpdateAsync(
            User.GetWorkspaceId(), id, User.GetUserId(), dto);

        return this.ToActionResult(result);
    }
}
