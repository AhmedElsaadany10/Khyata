using Khayata.API.Extensions;
using Khayata.Application.DTOs.Auth;
using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.API.Controllers;

[ApiController]
[Route("v1/auth")]
public sealed class AuthController(IAuthRepository authRepo) : ControllerBase
{
    /// <summary>
    /// Register a new workspace owner.
    /// Returns 202 — no token until an admin activates the workspace.
    /// </summary>
    [HttpPost("register")]
    [ProducesResponseType(StatusCodes.Status202Accepted)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register([FromBody] RegisterOwnerDto dto)
    {
        var result = await authRepo.RegisterOwnerAsync(dto);
        if (!result.IsSuccess) return this.ToActionResult(result);
        return Accepted(result.Value);
    }

    /// <summary>
    /// Login for owners and employees.
    /// Returns a JWT on success; 401/403 on bad credentials or inactive workspace.
    /// </summary>
    [HttpPost("login")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> Login([FromBody] LoginDto dto)
    {
        var result = await authRepo.LoginAsync(dto);
        return this.ToActionResult(result);
    }

    /// <summary>
    /// Owner creates an employee account in their workspace.
    /// The employee is auto-linked to the owner's workspace via the JWT claim.
    /// </summary>
    [HttpPost("employees")]
    [Authorize]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CreateEmployee([FromBody] CreateEmployeeDto dto)
    {
        if (User.GetRole() != "Owner")
            return StatusCode(403, new { code = 403, status = "Forbidden", message = "Only workspace owners can create employee accounts." });

        var result = await authRepo.CreateEmployeeAsync(User.GetWorkspaceId(), dto);
        return this.ToActionResult(result, successStatusCode: 201);
    }
}
