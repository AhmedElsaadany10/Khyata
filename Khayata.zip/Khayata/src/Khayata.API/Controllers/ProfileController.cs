using Khayata.API.Extensions;
using Khayata.Application.DTOs.Employee;
using Khayata.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Khayata.API.Controllers;

/// <summary>
/// Lets any authenticated user (owner or employee) update their own profile.
/// The owner uses this endpoint — not /employees — since they have no workspace-scoped employee record.
/// </summary>
[ApiController]
[Route("v1/profile")]
[Authorize]
public sealed class ProfileController(IUserRepository userRepo) : ControllerBase
{
    /// <summary>Update the currently authenticated user's name or password.</summary>
    [HttpPatch]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UpdateMyProfile([FromBody] UpdateEmployeeDto dto)
    {
        var userId = User.GetUserId();
        var role   = User.GetRole();

        var result = role == "Owner"
            ? await userRepo.UpdateOwnerAsync(userId, dto)
            : await userRepo.UpdateEmployeeAsync(User.GetWorkspaceId(), userId, dto);

        return this.ToActionResult(result);
    }
}
