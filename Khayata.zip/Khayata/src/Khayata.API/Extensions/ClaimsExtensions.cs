using System.Security.Claims;

namespace Khayata.API.Extensions;

public static class ClaimsExtensions
{
    public static Guid   GetUserId(this ClaimsPrincipal user) =>
        Guid.Parse(user.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? user.FindFirstValue("sub")!);

    public static Guid   GetWorkspaceId(this ClaimsPrincipal user) =>
        Guid.Parse(user.FindFirstValue("wid")!);

    public static string GetRole(this ClaimsPrincipal user) =>
        user.FindFirstValue("role") ?? "Employee";
}
